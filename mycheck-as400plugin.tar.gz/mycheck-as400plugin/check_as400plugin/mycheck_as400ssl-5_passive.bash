#!/bin/bash

################
### SETTINGS ###
################

CMDFILE="/usr/local/nagios/var/rw/nagios.cmd"
CMDEXECDIR="/usr/local/nagios/libexec/"
MYAS400LIST="${CMDEXECDIR}/myas400ssl-5-list"
MYDIRFORTMP=/var/nagiosramdisk/tmp
if [ -w "$MYDIRFORTMP" ]; then
  MYOUTMP="$MYDIRFORTMP/myoutmpas400ssl-5"
else
  MYOUTMP="/tmp/myoutmpas400ssl-5"
fi

#################
### FUNCTIONS ###
#################

GO_SERVICE_CHECK(){
MYHOSTNAME=`echo $i | cut -d: -f1`;MYIPADDR=`echo $i | cut -d: -f2`
MYHOSTLOW=$( echo ${MYHOSTNAME} | awk '{print tolower($0)}' )

#SERVICENAME="Active Jobs - ${MYHOSTNAME}"
#echo "${SERVICENAME} -->"
#echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v AJ -w 15000 -c 20000"
#COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v AJ -w 15000 -c 20000`
#EXIT=$?
#echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

SERVICENAME="ASP Storage SYSTEM - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v US -w 35 -c 30"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v US -w 35 -c 30`
EXIT=$?
echo $COMMAND > $MYOUTMP
MYOKNOT=$( cat "$MYOUTMP" | egrep '^OK|^WARNING|^CRITICAL' )
if [ ! -z "$MYOKNOT" ]; then
  MYPCTOUT=`cat $MYOUTMP | awk '{print $11}' | cut -d ';' -f1 | cut -d '=' -f2`
  MYRESULT1=`cat $MYOUTMP | awk '{print $1, $2}'`
  MYRESULT2=`cat $MYOUTMP | awk '{print $7, $8, $9, $10, $11}'`
  MYRESULT=`echo "$MYRESULT1 $MYPCTOUT $MYRESULT2"`
else
  MYRESULT=`cat $MYOUTMP`
fi
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$MYRESULT" >> $CMDFILE
#sleep 2

#SERVICENAME="CPU Load - ${MYHOSTNAME}"
#echo "${SERVICENAME} -->"
#echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v CPU -w 50 -c 80"
#COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v CPU -w 50 -c 80`
#EXIT=$?
#echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
##sleep 2

SERVICENAME="Disk Status - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v DISK -w 60 -c 70"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v DISK -w 60 -c 70`
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

SERVICENAME="Jobs - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v JOBS -w 90000 -c 100000"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v JOBS -w 90000 -c 100000`
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

SERVICENAME="Login Completion - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v LOGIN"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v LOGIN`
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

SERVICENAME="Problem - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v PRB"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v PRB`
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

SERVICENAME="Unanswered Message Queue - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v MSG QSYSOPR -w 0 -c 0"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v MSG QSYSOPR -w 0 -c 0`
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

SERVICENAME="Unanswered Message Wait - ${MYHOSTNAME}"
echo "${SERVICENAME} -->"
echo "/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v WRKACTJOB -w 0 -c 0"
COMMAND=`/bin/sudo /bin/timeout 240s ${CMDEXECDIR}check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v WRKACTJOB -w 0 -c 0`
if [ "$MYHOSTNAME" = "HLBSGDRP" ]; then
  COMMAND=`/bin/sudo /bin/timeout 240s /usr/local/nagios/libexec/AS400-ENTER/check_as400 ${MYHOSTLOW} -SSL -H ${MYIPADDR} -v WRKACTJOB -w 0 -c 0`
fi
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
#sleep 2

}

######################
### MAIN EXECUTION ###
######################

# Check if script already running
me="$(basename "$0")";
#running=$(ps h -C "$me" | grep -wv $$ | wc -l);
running=$(pidof -x "$me" -o $$ | wc -l);
#[[ $running > 1 ]] && exit;
[[ $running > 0 ]] && exit;

if [ -s ${MYAS400LIST} ]; then
  for i in $( grep -v '^#' ${MYAS400LIST} ); do
    [ "$i" ] && echo ""; GO_SERVICE_CHECK
  done
else
  echo "";echo "Error: Cannot find file ${MYAS400LIST}"; exit 1
fi

echo ""; echo "Last check on `date`"
rm -f $MYOUTMP
exit 0

