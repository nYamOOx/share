#!/bin/bash

################
### SETTINGS ###
################

CMDFILE="/usr/local/nagios/var/rw/nagios.cmd"
CMDEXECDIR="/usr/local/nagios/libexec/"
MYAS400LIST="${CMDEXECDIR}/myas400ibmi-5-list"
MYDIRFORTMP=/var/nagiosramdisk/tmp
if [ -w "$MYDIRFORTMP" ]; then
  MYOUTMP="$MYDIRFORTMP/myoutmpas400ibmi-5"
else
  MYOUTMP="/tmp/myoutmpas400ibmi-5"
fi

#################
### FUNCTIONS ###
#################

GO_SERVICE_CHECK(){
MYHOSTNAME=`echo $i | cut -d: -f1`;MYIPADDR=`echo $i | cut -d: -f2`

for j in `cat ${CMDEXECDIR}mymessageid-list`; do
SERVICENAME="${MYHOSTNAME} - Message ID $j"
echo "${SERVICENAME} -->"
#-- OLD STYLE
#echo "/bin/timeout 240s /bin/bash ${CMDEXECDIR}mycheck_as400-messageid.bash -H ${MYIPADDR} -I $j"
#COMMAND=`/bin/timeout 240s /bin/bash ${CMDEXECDIR}mycheck_as400-messageid.bash -H ${MYIPADDR} -I $j`
#--
#-- NEW STYLE
echo "/bin/timeout 240s /bin/bash ${CMDEXECDIR}check_ibmi_status.sh -ssl y -m CustomSQL -H ${MYIPADDR} -f ReplyMsg | grep $j"
#COMMAND=`/bin/timeout 240s /bin/bash ${CMDEXECDIR}check_ibmi_status.sh -m CustomSQL -H ${MYIPADDR} -f ReplyMsg | grep $j`
COMMAND=`/bin/timeout 240s /bin/bash ${CMDEXECDIR}mycheck_as400-messageid.bash -H ${MYIPADDR} -i $j`
#--
EXIT=$?
echo "[`date +%s`] PROCESS_SERVICE_CHECK_RESULT;$MYHOSTNAME;$SERVICENAME;$EXIT;$COMMAND" >> $CMDFILE
echo $COMMAND
done
}

######################
### MAIN EXECUTION ###
######################

# Check if script already running
me="$(basename "$0")";
echo $me
#running=$(ps h -C "$me" | grep -wv $$ | wc -l);
running=$(pidof -x "$me" -o $$ | wc -l);
echo $running
#[[ $running > 1 ]] && exit;
[[ $running > 0 ]] && exit;

if [ -s ${MYAS400LIST} ]; then
  for i in $( grep -v '^#' ${MYAS400LIST} ); do
    [ "$i" ] && echo ""; GO_SERVICE_CHECK
  done
else
  echo "";echo "Error: Cannot find file ${MYAS400LIST}"; exit 1
fi

echo ""; echo "Last check on `date`"
rm -f $MYOUTMP
exit 0

