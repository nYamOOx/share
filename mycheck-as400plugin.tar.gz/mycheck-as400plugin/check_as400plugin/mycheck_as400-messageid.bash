#!/bin/bash

# Nagios Exit Codes
OK=0
WARNING=1
CRITICAL=2
UNKNOWN=3

# set default values for the thresholds
WARN=80
CRIT=90

usage()
{
cat <<EOF

Check AS400 Message ID

     Options:
	-H         Hostname/IP Address
        -i         Message ID
	-h	   Usage

Sample Usage: $0 -H 10.1.1.1 -i CPPEA01
EOF
}


while getopts "H:i:h" ARG;
do
        case $ARG in
                H) MYHOST=$OPTARG
                   ;;
                i) MSGID=$OPTARG
                   ;;
                h) usage
                   exit
                   ;;
        esac
done

# Check AS400 Message ID

MYDIRFORTMP=/var/nagiosramdisk/tmp
if [ -w "$MYDIRFORTMP" ]; then
  MYOUTMP="$MYDIRFORTMP/$MYHOST-msgidcheckout"
  MYOUTMPERR="$MYDIRFORTMP/$MYHOST-msgidcheckouterr"
else
  MYOUTMP="/tmp/$MYHOST-msgidcheckout"
  MYOUTMPERR="/tmp/$MYHOST-msgidcheckouterr"
fi
msgidout=`/bin/timeout 120s /bin/bash /usr/local/nagios/libexec/check_ibmi_status.sh -ssl -m CustomSQL -H $MYHOST -f ReplyMsg | grep $MSGID`

# End Checking

RESULT=$(echo "No $MSGID found")

MYRESULT=$( echo "$msgidout" )
if [ -z "$MYRESULT" ]; then
        RESULT=$(echo "No $MSGID found")
        echo "OK: $RESULT"
        rm -f $MYOUTMP $MYOUTMPERR
        exit $OK;
else
	echo "CRITICAL: $MYRESULT"
        rm -f $MYOUTMP $MYOUTMPERR
	exit $CRITICAL;
fi

