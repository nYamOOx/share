#!/bin/bash

# Nagios Exit Codes
OK=0
WARNING=1
CRITICAL=2
UNKNOWN=3

# set default values for the thresholds
WARN=80
CRIT=90

usage()
{
cat <<EOF

Check AS400 Message ID

     Options:
	-H         Hostname/IP Address
	-h	   Usage

Sample Usage: $0 -H 10.1.1.1
EOF
}


while getopts "H:h" ARG;
do
        case $ARG in
                H) MYHOST=$OPTARG
                   ;;
                h) usage
                   exit
                   ;;
        esac
done

# Check AS400 Unanswered Message Queue

MYTODAY=`date | awk '{print $1, $2, $3}'`

MYDIRFORTMP=/var/nagiosramdisk/tmp
if [ -w "$MYDIRFORTMP" ]; then
  MYOUTMP="$MYDIRFORTMP/$MYHOST-unansweredmsgcheckout"
  MYOUTMPERR="$MYDIRFORTMP/$MYHOST-unansweredmsgcheckouterr"
else
  MYOUTMP="/tmp/$MYHOST-msgidcheckout"
  MYOUTMPERR="/tmp/$MYHOST-msgidcheckouterr"
fi
msgidout=`/bin/timeout 120s /bin/bash /usr/local/nagios/libexec/check_ibmi_status.sh -ssl -m Message -H $MYHOST -lib QSYS -name QSYSOPR -ty REPLY` | grep "$MYTODAY"

# End Checking

RESULT=$(echo "No messages")

MYRESULT=$( echo "$msgidout" )
if [ -z "$MYRESULT" ]; then
        RESULT=$(echo "No messages")
        echo "OK: $RESULT"
        rm -f $MYOUTMP $MYOUTMPERR
        exit $OK;
else
	echo "CRITICAL: $MYRESULT"
        rm -f $MYOUTMP $MYOUTMPERR
	exit $CRITICAL;
fi

